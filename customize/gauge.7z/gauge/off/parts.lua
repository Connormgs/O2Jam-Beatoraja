local parts = {}

local function load(g)
	return parts
end

return {
	parts = parts,
	load = load
}